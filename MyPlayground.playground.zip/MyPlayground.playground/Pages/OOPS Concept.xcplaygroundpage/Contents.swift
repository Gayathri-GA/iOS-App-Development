// Object Oriented Concepts

// Inheritance - Parent -> Child


import SwiftUI

class MicroPhone{
    var color: String = "BlueGrey"
    var type: String = "Atmos"
    
    // Convenient init type
    init(){
        
    }
    convenience init(micColor:String, micType:String) {
        self.init()
        color = micColor
        type = micType
    }
    
    // Methods
    func turnOn(){
        print("\(self.type) microphone is turned ON")
    }
    func showAboutMic() -> String {
        return "This is \(self.type) microphone. It is available for purchase in \(self.color) color"
    }
}

// Inherited Class
class Lapel: MicroPhone {
    // property
    var clipType : String = "Black clip"
    var lapelName : String = "Lapel"
    func lapelStuff() {
        print("I am just a lapel mic")
    }
    
    override func turnOn() {
        let superName = super.type
        print("Making sound as \(self.lapelName) and not as a \(superName)")
    }
}

let lapelOne = Lapel()
lapelOne.lapelStuff()
lapelOne.turnOn()


let blueMic = MicroPhone(micColor: "Blue", micType: "Dolby")
let defaultMic = MicroPhone()
defaultMic.turnOn()
print(defaultMic.showAboutMic())
