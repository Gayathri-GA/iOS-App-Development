// Structs in Swift

import UIKit

// Struct
struct Person {
    // properties
    var name: String
    var age: Int
}

let james = Person(name:"James", age: 90)

print(james.name)
