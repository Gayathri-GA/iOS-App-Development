import SwiftUI

class MicroPhone{
    var color: String = "BlueGrey"
    var type: String = "Atmos"
    
    // Convenient init type
    init(){
        
    }
    convenience init(micColor:String, micType:String) {
        self.init()
        color = micColor
        type = micType
    }
    
    // Methods
    func turnOn(){
        print("\(self.type) microphone is turned ON")
    }
    func showAboutMic() -> String {
        return "This is \(self.type) microphone. It is available for purchase in \(self.color) color"
    }
}

let blueMic = MicroPhone(micColor: "Blue", micType: "Dolby")
let defaultMic = MicroPhone()
defaultMic.turnOn()
print(defaultMic.showAboutMic())
// TRY OUTS
//print("Default Mic, Color: \(defaultMic.color), Type: \(defaultMic.type)")
//print(blueMic.color)
//print(blueMic.type)
