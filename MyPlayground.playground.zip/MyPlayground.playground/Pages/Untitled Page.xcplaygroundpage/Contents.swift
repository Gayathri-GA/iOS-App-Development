import UIKit

// Create Classes
class MicroPhone{
    // Properties
    var color: String
    var type: String
    var brandName: String
    // initializers
    init(micColor: String, mictype: String, micBrandName:String) {
        color = micColor
        type = mictype
        brandName = micBrandName
    }
}

// Create the actual object
let indigoDolby = MicroPhone(micColor: "Blue", mictype: "Dynamic", micBrandName: "Dolby")
//indigoDolby.color = "Blue"
//indigoDolby.type = "Dynamic"


print(indigoDolby.color)
